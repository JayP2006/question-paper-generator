const Question = require('../models/Question');
const Syllabus = require('../models/Syllabus');

function shuffle(arr) {
    return arr.sort(() => Math.random() - 0.5);
}

exports.generatePaperData = async (blueprintId, rules=null) => {

    const Blueprint = require("../models/Blueprint");

    const blueprint = await Blueprint.findById(blueprintId);

    if(!blueprint) throw new Error("Blueprint not found");

    const generated = {questions:[]};

    const q3 = shuffle(await Question.find({marks:3}));
    const q4 = shuffle(await Question.find({marks:4}));
    const q7 = shuffle(await Question.find({marks:7}));

    let i3=0,i4=0,i7=0;

    let pattern = blueprint.questions;

    if(rules && rules.simpleQuestions){

    const result = { questions: [] };

    for(let i=0;i<rules.totalQuestions;i++){

        let q;

        if(rules.marks===3){
            q=q3[i3++ % q3.length];
        }

        else if(rules.marks===4){
            q=q4[i4++ % q4.length];
        }

        else{
            q=q7[i7++ % q7.length];
        }

        result.questions.push({
            number: i+1,
            parts:[
                {
                    label:"a",
                    marks:q.marks,
                    questionText:q.questionText
                }
            ]
        });

    }

    return result;
}

};