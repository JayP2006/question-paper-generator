const jwt = require("jsonwebtoken");

const JWT_SECRET = "supersecretkey";

module.exports = function(req,res,next){

    const token = req.headers.authorization;

    if(!token){

        return res.status(401).json({
            error:"Unauthorized"
        });

    }

    try{

        const decoded = jwt.verify(token,JWT_SECRET);

        req.user = decoded;

        next();

    }

    catch(err){

        res.status(401).json({
            error:"Invalid token"
        });

    }

};